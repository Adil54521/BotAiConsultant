require("dotenv").config({ path: "config.env" });

const route = require('http');
const jwt = require('jsonwebtoken');
const port = process.env.PORT || 8000;

const {
    register,
    login,
    getUserById,
    updateUser
} = require('./auth/auth');

const {
    getOrCreateChat,
    saveMessage,
    getChats,
    getMessages,
    deleteChat,
    setConsultantMode,
    isConsultantMode,
    getUnsentEmployeeMessages,
    markMessagesAsSentToBot
} = require("./chat");

const WebSocket = require('ws');

const server = route.createServer(async (req, res) => {
    res.setHeader('Content-Type', 'text/plain');
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:63342');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader(
        "Access-Control-Allow-Credentials",
        "true"
    );

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }
    if (req.url === '/register') {
        let parse = '';
        res.statusCode = 200;
        req.on('data', chunk => {
            parse = chunk.toString();
        });
        req.on('end', async () => {
            try {
                const body = parse ? JSON.parse (parse): {};
                if (!body.name || !body.mail || !body.password) {
                    res.statusCode = 400;
                    return res.end(JSON.stringify({
                        message: "Заполните все поля!"
                    }));
                }
                await register(
                    body.name,
                    body.mail,
                    body.password
                );

                res.end(JSON.stringify({message: "Вы зарегистрированы !"}));
            } catch (err) {
                console.error(51, err);

                res.statusCode = 500;
                res.end(JSON.stringify({
                    message: "Пользователь с таким именем уже существует"
                }));
            }
        });
        return;
    }

    if (req.url === "/login" && req.method === "POST") {
        let parse = "";

        req.on("data", chunk => {
            parse += chunk;
        });

        req.on("end", async () => {
            try {
                const body = JSON.parse(parse);

                const user = await login(
                    body.login,
                    body.passwordd
                );

                if (!user) {
                    res.statusCode = 401;

                    return res.end(JSON.stringify({
                        message: "Неверный логин или пароль"
                    }));
                }

                const token = jwt.sign(
                    {
                        userId: user.id
                    },
                    "secret_key",
                    {
                        expiresIn: "7d"
                    }
                );

                res.setHeader(
                    "Set-Cookie",
                    `accessToken=${token}; HttpOnly; Path=/`
                );

                res.end(JSON.stringify({
                    message: "Вход выполнен"
                }));

            } catch (err) {
                console.error(err);

                res.statusCode = 500;

                res.end(JSON.stringify({
                    message: "Ошибка сервера"
                }));
            }
        });

        return;
    }

    if (req.url === "/profile" && req.method === "GET") {
        try {
            const cookies = req.headers.cookie || "";

            const token = cookies
                .split("; ")
                .find(c => c.startsWith("accessToken="))
                ?.split("=")[1];

            if (!token) {
                res.statusCode = 401;

                return res.end(JSON.stringify({
                    message: "Нет токена"
                }));
            }

            const payload = jwt.verify(
                token,
                "secret_key"
            );

            const user = await getUserById(
                payload.userId
            );

            if (!user) {
                res.statusCode = 404;

                return res.end(JSON.stringify({
                    message: "Пользователь не найден"
                }));
            }

            res.setHeader(
                "Content-Type",
                "application/json"
            );

            res.end(JSON.stringify({
                id: user.id,
                login: user.login,
                email: user.email,
                created_at: user.created_at
            }));

        } catch (err) {
            console.error(err);

            res.statusCode = 401;

            res.end(JSON.stringify({
                message: "Недействительный токен"
            }));
        }

        return;
    }
    if (req.url === '/profile' && req.method === 'PUT') {
        let parse = '';

        req.on('data', chunk => {
            parse += chunk;
        });

        req.on('end', async () => {
            try {
                const cookies = req.headers.cookie || '';

                const token = cookies
                    .split('; ')
                    .find(c => c.startsWith('accessToken='))
                    ?.split('=')[1];

                if (!token) {
                    res.statusCode = 401;

                    return res.end(JSON.stringify({
                        message: 'Нет токена'
                    }));
                }

                const payload = jwt.verify(
                    token,
                    'secret_key'
                );

                const body = JSON.parse(parse);

                if (!body.login || !body.email) {
                    res.statusCode = 400;

                    return res.end(JSON.stringify({
                        message: 'Заполните все поля'
                    }));
                }

                const emailRegex =
                    /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                if (!emailRegex.test(body.email)) {
                    res.statusCode = 400;

                    return res.end(JSON.stringify({
                        message: 'Некорректный email'
                    }));
                }

                await updateUser(
                    payload.userId,
                    body.login,
                    body.email
                );

                res.end(JSON.stringify({
                    message: 'Данные успешно обновлены'
                }));

            } catch (err) {
                console.error(err);

                res.statusCode = 500;

                res.end(JSON.stringify({
                    message: 'Ошибка сервера'
                }));
            }
        });

        return;
    }

    if (req.url === "/message" && req.method === "POST") {

        let body = "";

        req.on("data", chunk => {
            body += chunk;
        });

        req.on("end", async () => {

            const message = JSON.parse(body);

            // Получаем существующий чат или создаем новый
            const chatId = await getOrCreateChat(
                message.studentId,
                message.studentName,
                message.phone
            );

            // Сохраняем сообщение
            await saveMessage(
                chatId,
                "student",
                message.text
            );

            // Отправляем сообщение сотрудникам
            wss.clients.forEach(client => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send(JSON.stringify({
                        type: "new_message",
                        chatId: chatId,
                        studentId: message.studentId,
                        phone: message.phone,
                        studentName: message.studentName,
                        text: message.text
                    }));
                }
            });

        });

        return;
    }

    if (req.url.startsWith("/message?") && req.method === "GET") {

        try {

            const url = new URL(req.url, "http://localhost:8000");

            const chatId = url.searchParams.get("chatId");

            const messages = await getMessages(chatId);

            res.setHeader(
                "Content-Type",
                "application/json"
            );

            res.end(JSON.stringify(messages));

        } catch (err) {

            console.error(err);

            res.statusCode = 500;

            res.end(JSON.stringify({
                message: "Ошибка сервера"
            }));

        }

        return;
    }

    if (req.url === "/chat" && req.method === "GET") {

        try {

            const chats = await getChats();

            res.setHeader(
                "Content-Type",
                "application/json"
            );

            res.end(JSON.stringify(chats));

        } catch (err) {

            console.error(err);

            res.statusCode = 500;

            res.end(JSON.stringify({
                message: "Ошибка сервера"
            }));

        }

        return;
    }

    if (req.url.startsWith("/chat/") && req.method === "DELETE") {
        try {
            const chatId = req.url.split("/")[2];

            await deleteChat(chatId);

            res.end(JSON.stringify({
                message: "Чат удален"
            }));

        } catch (err) {

            console.error(err);

            res.statusCode = 500;

            res.end(JSON.stringify({
                message: "Ошибка сервера"
            }));

        }

        return;
    }

    if (req.url === "/send-message" && req.method === "POST") {

        let body = "";

        req.on("data", chunk => {
            body += chunk;
        });

        req.on("end", async () => {

            const data = JSON.parse(body);

            // Получаем информацию о чате
            const chats = await getChats();

            const chat = chats.find(c => c.id == data.chatId);

            // Сохраняем сообщение сотрудника
            const savedMessage = await saveMessage(
                data.chatId,
                "employee",
                data.text
            );

            const active = await isConsultantMode(chat.student_id);
            console.log("ACTIVE:", active);

            if (active) {
                if (botClients.size === 0) {
                    console.log("Bot not connected");
                } else {
                    botClients.forEach(bot => {
                        if (bot.readyState === WebSocket.OPEN) {
                            bot.send(JSON.stringify({
                                type: "employee_message",
                                telegramId: chat.student_id,
                                chatId: data.chatId,
                                text: data.text
                            }));
                        }
                    });

                    await markMessagesAsSentToBot([savedMessage.id]);
                }
            }

            // Обновляем страницу сотрудника
            wss.clients.forEach(client => {
                if (
                    !botClients.has(client) &&
                    client.readyState === WebSocket.OPEN
                ) {
                    client.send(JSON.stringify({
                        type: "employee_message",
                        chatId: data.chatId,
                        text: data.text
                    }));
                }
            });

            res.end("ok");

        });

        return;
    }

    if (req.url === "/consultant-mode" && req.method === "POST") {

        let body = "";

        req.on("data", chunk => {
            body += chunk;
        });

        req.on("end", async () => {
            try {
                const data = JSON.parse(body);

                const enabled = data.enabled === true;

                await setConsultantMode(
                    data.studentId,
                    enabled
                );

                if (enabled === true) {
                    const chats = await getChats();

                    const chat = chats.find(c => String(c.student_id) === String(data.studentId));

                    if (chat) {
                        const unsentMessages = await getUnsentEmployeeMessages(chat.id);

                        if (unsentMessages.length > 0) {
                            botClients.forEach(bot => {
                                if (bot.readyState === WebSocket.OPEN) {
                                    unsentMessages.forEach(message => {
                                        bot.send(JSON.stringify({
                                            type: "employee_message",
                                            telegramId: chat.student_id,
                                            chatId: chat.id,
                                            text: message.text
                                        }));
                                    });
                                }
                            });

                            await markMessagesAsSentToBot(
                                unsentMessages.map(message => message.id)
                            );
                        }
                    }
                }

                wss.clients.forEach(client => {
                    if (
                        !botClients.has(client) &&
                        client.readyState === WebSocket.OPEN
                    ) {
                        client.send(JSON.stringify({
                            type: "consultant_mode_changed",
                            studentId: data.studentId,
                            enabled: enabled
                        }));
                    }
                });

                res.setHeader("Content-Type", "application/json");

                res.end(JSON.stringify({
                    message: "Статус обновлён",
                    studentId: data.studentId,
                    enabled: enabled
                }));

            } catch (err) {
                console.error(err);

                res.statusCode = 500;

                res.end(JSON.stringify({
                    message: "Ошибка сервера"
                }));
            }
        });

        return;
    }

    if (req.url.startsWith("/consultant-mode?") && req.method === "GET") {
        try {
            const url = new URL(req.url, "http://localhost:8000");
            const studentId = url.searchParams.get("studentId");

            const enabled = await isConsultantMode(studentId);

            res.setHeader("Content-Type", "application/json");

            res.end(JSON.stringify({
                studentId,
                enabled
            }));
        } catch (err) {
            console.error(err);

            res.statusCode = 500;

            res.end(JSON.stringify({
                message: "Ошибка сервера"
            }));
        }

        return;
    }
    res.statusCode = 404;
    res.end(JSON.stringify({
       message: "Not found"
    }));
})

const wss = new WebSocket.Server({server});

const botClients = new Set();
wss.on("connection", (ws) => {
    console.log("WebSocket клиент подключился");
    ws.on("message", message => {

        try {

            const data = JSON.parse(message);

            if (data.type === "bot") {
               botClients.add(ws);
               console.log("Bot connected");
            }

        } catch {}

    });

    ws.on("close", () => {
        botClients.delete(ws);
    });

});
server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
