from aiogram import Bot, Dispatcher, F, Router
from aiogram.types import (Message, KeyboardButton,
                           Update,
                           ReplyKeyboardMarkup,
                           ReplyKeyboardRemove,
                           Contact)
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
import os
from os import getenv
import asyncio
from dotenv import load_dotenv
from ai_service import *
import aiohttp
from aiogram.client.session.aiohttp import AiohttpSession
from pydantic import BaseModel
import asyncio
import json
import websockets

path_env = os.path.join("C:\\BotAiConsultant", ".env")
load_dotenv(path_env)

TOKEN = os.getenv('BOT_TOKEN')
dp = Dispatcher()

my_router = Router()
bachelor = Gemini()
bachelor.create_university_cache()
bot = Bot(token=TOKEN)

menu = ReplyKeyboardMarkup(
    keyboard = [
        [KeyboardButton(text="Отправить номер телефона", request_contact=True)]
    ],
    resize_keyboard=True,
)

main_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Режим ИИ")],
        [KeyboardButton(text="Связаться с сотрудником")],
    ],
    resize_keyboard=True
)

ai_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Выход")]
    ],
    resize_keyboard=True
)

consultant_exit = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="Выход из режима общения с сотрудником")]
    ],
    resize_keyboard=True
)
class AIState(StatesGroup):
    active = State()

class ConnectState(StatesGroup):
    connect = State()

@dp.message(CommandStart())
async def start(message: Message):
    full_name = message.from_user.full_name
    await message.answer(f"Приветствую, {full_name}, это бот для консультации по академической мобильности !"
                         f"Чтобы получить консультацию отправьте свой номер по кнопке ниже",
                         reply_markup=menu)

@dp.message(F.contact)
async def get_contact(message: Message, state: FSMContext):
    phone = message.contact.phone_number
    await state.update_data(phone=phone)
    await message.answer(f"Вы отправили номер: {phone}")
    if phone:
        await message.answer("Номер телефона получен. Для запуска ИИ режима нажмите кнопку ниже", reply_markup=ReplyKeyboardRemove())

    await message.answer("Выберите режим:", reply_markup=main_keyboard)

@dp.message(AIState.active, F.text != "Выход")
async def process_ai(message: Message):
    user_input = message.text
    response = bachelor.ask_ai(user_input)
    await message.answer(response)

@dp.message(F.text == "Режим ИИ")
async def ai_mode(message: Message, state: FSMContext):
    await state.set_state(AIState.active)
    await message.answer(
        "ИИ режим включён. Пишите сообщения.",
        reply_markup=ai_keyboard  # тут кнопка "Выход"
    )

@dp.message(F.text == "Выход", AIState.active)
async def exit_ai(message: Message, state: FSMContext):
    await state.clear()
    await message.answer(
        "ИИ режим выключен",
        reply_markup=main_keyboard
    )

@dp.message(F.text == "Связаться с сотрудником")
async def httprequest(message: Message, state: FSMContext):

    await state.set_state(ConnectState.connect)
    async with aiohttp.ClientSession() as session:
        await session.post(
            "http://localhost:8000/consultant-mode",
            json={
                "studentId": message.from_user.id,
                "enabled": True
            }
        )
    await message.answer(
        "Вы подключены к сотруднику. Напишите сообщение.",
        reply_markup=consultant_exit
    )

@dp.message(ConnectState.connect, F.text != "Выход из режима общения с сотрудником")
async def connect_chat(message: Message, state: FSMContext):
    data = await state.get_data()
    phone = data.get("phone")
    async with aiohttp.ClientSession() as session:
        async with session.post(
            "http://localhost:8000/message",
            json={
                "studentId": message.from_user.id,
                "phone": phone,
                "studentName": message.from_user.username,
                "text": message.text
            }
        ) as response:
            text = await response.text()

    # если сервер ничего не возвращает, можно убрать эту строку
    await message.answer(text)

async def websocket_listener():
    while True:
        try:
            async with websockets.connect("ws://localhost:8000") as ws:

                await ws.send(json.dumps({
                    "type": "bot"
                }))

                print("Bot connected to WebSocket")

                while True:

                    message = await ws.recv()

                    print("RAW:", message)

                    data = json.loads(message)

                    print("DATA:", data)
                    if data["type"] == "employee_message":

                        telegram_id = data["telegramId"]

                        state = dp.fsm.get_context(
                            bot=bot,
                            chat_id=telegram_id,
                            user_id=telegram_id
                        )

                        current_state = await state.get_state()

                        print("current_state =", current_state)
                        print("need_state =", ConnectState.connect.state)

                        try:
                            await bot.send_message(
                                telegram_id,
                                data["text"]
                            )
                            print("Сообщение отправлено")
                        except Exception as e:
                            print(e)

        except Exception as e:
            print(e)

        await asyncio.sleep(5)

@dp.message(F.text == "Выход из режима общения с сотрудником")
async def exit_httprequest(message: Message, state: FSMContext):
    async with aiohttp.ClientSession() as session:
        await session.post(
            "http://localhost:8000/consultant-mode",
            json={
                "studentId": message.from_user.id,
                "enabled": False
            }
        )
    await state.clear()

    await message.answer(
        "Вы вышли из режима общения с сотрудником",
        reply_markup=main_keyboard
    )

async def main():
    await asyncio.gather(
        dp.start_polling(bot),
        websocket_listener()
    )

    await bot.close()

if __name__ == '__main__':
    asyncio.run(main())

