const pool = require("./db");

async function getOrCreateChat(studentId, studentName, phone) {
    let result = await pool.query(
        `SELECT id
         FROM chats
         WHERE student_id = $1`,
        [studentId]
    );

    if (result.rows.length > 0) {
        return result.rows[0].id;
    }

    result = await pool.query(
        `INSERT INTO chats(student_id, student_name, phone)
         VALUES($1, $2, $3)
         RETURNING id`,
        [studentId, studentName, phone]
    );

    return result.rows[0].id;
}

async function saveMessage(chatId, sender, text) {
    const result = await pool.query(
        `
        INSERT INTO messages(chat_id, sender, text)
        VALUES($1, $2, $3)
        RETURNING *
        `,
        [chatId, sender, text]
    );

    return result.rows[0];
}

async function getChats() {
    const result = await pool.query(`
        SELECT *
        FROM chats
        ORDER BY created_at DESC
    `);

    return result.rows;
}

async function getMessages(chatId) {
    const result = await pool.query(
        `SELECT *
         FROM messages
         WHERE chat_id = $1
         ORDER BY created_at`,
        [chatId]
    );

    return result.rows;
}

async function deleteChat(chatId) {
    await pool.query(
        `DELETE FROM chats
         WHERE id = $1`,
        [chatId]
    );
}

async function setConsultantMode(studentId, enabled) {
    await pool.query(
        `
        UPDATE chats
        SET consultant_mode = $1
        WHERE student_id = $2
        `,
        [enabled, studentId]
    );
}

async function isConsultantMode(studentId) {

    const result = await pool.query(
        `
        SELECT consultant_mode
        FROM chats
        WHERE student_id = $1
        `,
        [studentId]
    );

    if (result.rows.length === 0) {
        return false;
    }

    return result.rows[0].consultant_mode;
}

async function getUnsentEmployeeMessages(chatId) {
    const result = await pool.query(
        `
        SELECT *
        FROM messages
        WHERE chat_id = $1
          AND sender = 'employee'
          AND sent_to_bot = false
        ORDER BY created_at
        `,
        [chatId]
    );

    return result.rows;
}

async function markMessagesAsSentToBot(messageIds) {
    if (messageIds.length === 0) {
        return;
    }

    await pool.query(
        `
        UPDATE messages
        SET sent_to_bot = true
        WHERE id = ANY($1::int[])
        `,
        [messageIds]
    );
}

module.exports = {
    getOrCreateChat,
    saveMessage,
    getChats,
    getMessages,
    deleteChat,
    setConsultantMode,
    isConsultantMode,
    getUnsentEmployeeMessages,
    markMessagesAsSentToBot
};