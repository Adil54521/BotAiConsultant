  document.addEventListener("DOMContentLoaded", () => {
       clickButton();
       changeFormRight();
       changeFormLeft();
       clickToSend();
  });

  const signInButton = document.getElementById('signIn');
  const sign = document.getElementById('sgn');
  const signup = document.getElementById('sgn-up');
  const name = document.getElementById('name');
  const mail = document.getElementById('mail');
  console.log(name);
  console.log(mail);
  const password = document.getElementById('password');
  const login = document.getElementById('login');
  const passwordd = document.getElementById('passwordism');
  const data = new Map();
  let err = document.getElementById("error");
  let error = document.getElementById("errorin");
  console.log(15, err);

  function clickButton() {
     sign.addEventListener("click", async () => {
        Login();
     })
  }

  function clickToSend() {
    signup.addEventListener("click", () => {
        Registration();
    })
  }

async function Login() {
  const response = await fetch("http://localhost:8000/login", {
      method: "POST",
      credentials: "include",
      headers: {
          "Content-Type": "application/json"
      },
      body: JSON.stringify({
          login: login.value,
          passwordd: passwordd.value
      })
  });

  const result = await response.json();

  console.log(15, result);
  if (response.ok) {
      window.location.href = "http://localhost:63342/BotAiConsultant/account.html";
  } else if (!response.ok){
      error.textContent = result.message;
      error.style.color = "red";
      console.log(error);
  }
}

  const signUpButton = document.getElementById('signUp');
  const container = document.getElementById('container');

  function changeFormRight() {
      signUpButton.addEventListener('click', () => {
        container.classList.add("right-panel-active");
      });
  }

  function changeFormLeft() {
      signInButton.addEventListener('click', () => {
         container.classList.remove("right-panel-active");
      });
  }

async function Registration() {
    const response = await fetch("http://localhost:8000/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            name: name.value,
            mail: mail.value,
            password: password.value
        })
    });

    const result = await response.json();
    console.log(56, result);
    if (!response.ok) {
       console.log(74, result.message);
       err.textContent = result.message;
       err.style.color = "red";
    } else {
       err.textContent = "Вы зарегистрировались !";
       err.style.color = "green";
       console.log(result.message);
    }
}