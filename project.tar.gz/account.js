let allChats = [];
async function deleteChat(chatId) {

    if (!confirm("Удалить чат?")) {
        return;
    }

    const response = await fetch(
        `http://localhost:8000/chat/${chatId}`,
        {
            method: "DELETE"
        }
    );

    const result = await response.json();

    if (!response.ok) {
        alert(result.message);
        return;
    }

    // Удаляем чат из списка
    document.querySelector(
        `.chat-item[data-chat-id="${chatId}"]`
    )?.remove();

    // Если удалили открытый чат
    if (currentChatId === chatId) {

        currentChatId = null;

        document.getElementById("chatBody").innerHTML = "";

        const firstChat = document.querySelector(".chat-item");

        if (firstChat) {
            openChat(firstChat.dataset.chatId);
        }
    }

    alert(result.message);
}

function initEditMode() {
    const editBtn = document.getElementById('editBtn');
    let editing = false;

    editBtn.addEventListener('click', () => {
        editing = !editing;

        const inputs = document.querySelectorAll(
            '#login, #email, #password'
        );

        inputs.forEach(input => {
            input.readOnly = !editing;
        });

        editBtn.textContent = editing
            ? 'Отключить редактирование'
            : 'Редактировать';
    });
}

let currentChatId = null;
let currentStudentId = null;

async function loadChats() {
    const response = await fetch(
        "http://localhost:8000/chat"
    );

    if (!response.ok) {
        console.error("Не удалось загрузить чаты");
        return;
    }

    const chats = await response.json();

    allChats = chats;

    const chatList = document.querySelector(".chat-list");

    chatList.innerHTML = "";

    chats.forEach(chat => {

        const chatItem = document.createElement("div");

        chatItem.className = "chat-item";
        chatItem.dataset.chatId = chat.id;
        chatItem.dataset.studentId = chat.student_id;

        chatItem.innerHTML = `
            <div class="name">${chat.student_name}</div>
            <div class="phone">${chat.phone}</div>
            <div class="last-message"></div>
            <button class="delete-chat">🗑</button>
        `;

        chatItem.addEventListener("click", () => {
            openChat(chat.id);
        });

        chatItem.querySelector(".delete-chat").addEventListener("click", (e) => {
            e.stopPropagation(); // чтобы не открывался чат
            deleteChat(chat.id);
        });

        chatList.appendChild(chatItem);

    });

    // Если есть хотя бы один чат — открыть первый
    if (chats.length > 0) {
        openChat(chats[0].id);
    }
}

async function loadProfile() {
    const response = await fetch(
        "http://localhost:8000/profile",
        {
            credentials: "include"
        }
    );

    const user = await response.json();

    if (!response.ok) {
        console.error(user.message);
        return;
    }

    document.getElementById("login").value =
        user.login;

    document.getElementById("email").value =
        user.email;

    document.getElementById("date").value =
        user.created_at;
}

const saveBtn = document.getElementById('saveBtn');

saveBtn.addEventListener('click', saveProfile);

async function saveProfile() {
    const response = await fetch(
        'http://localhost:8000/profile',
        {
            method: 'PUT',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                login: document.getElementById('login').value,
                email: document.getElementById('email').value
            })
        }
    );

    const result = await response.json();

    if (response.ok) {
        alert(result.message);
    } else {
        alert(result.message);
    }
}

const profilePage = document.getElementById('profilePage');
const chatPage = document.getElementById('chatPage');

function openPage(pageName) {
    profilePage.style.display = 'none';
    chatPage.style.display = 'none';

    if (pageName === 'profile') {
        profilePage.style.display = 'block';
    }

    if (pageName === 'chat') {
        chatPage.style.display = 'block';
    }
}

document.getElementById('profileBtn').addEventListener('click', e => {
    e.preventDefault();
    openPage('profile');
});

document.getElementById('chatBtn').addEventListener('click', e => {
    e.preventDefault();
    openPage('chat');
});

const ws = new WebSocket("ws://localhost:8000");

ws.onopen = () => {
    console.log("WebSocket подключен");
};

const chatList = document.querySelector(".chat-list");

function renderMessage(sender, text) {
    const chatBody = document.getElementById("chatBody");

    const messageDiv = document.createElement("div");
    messageDiv.className = "message";

    if (sender === "employee") {
        messageDiv.classList.add("me");
    } else {
        messageDiv.classList.add("student");
    }

    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;

    messageDiv.appendChild(bubble);
    chatBody.appendChild(messageDiv);

    chatBody.scrollTop = chatBody.scrollHeight;
}

function renderChats(chats) {
    const chatItems = document.getElementById('chatItems');

    chatItems.innerHTML = '';

    chats.forEach(chat => {
        const item = document.createElement('div');
        item.className = 'chat-item';

        if (chat.id === currentChatId) {
            item.classList.add('active');
        }

        item.innerHTML = `
            <div class="name">${chat.student_name}</div>
            <div class="phone">${chat.phone || ''}</div>
            <div class="last-message">${chat.last_message || ''}</div>
            <button class="delete-chat-btn" data-id="${chat.id}">🗑</button>
        `;

        item.addEventListener('click', () => {
            openChat(chat.id);
        });

        const deleteBtn = item.querySelector('.delete-chat-btn');

        deleteBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            await deleteChat(chat.id);
        });

        chatItems.appendChild(item);
    });
}

function updateStudentStatus(studentId, enabled) {
    console.log("STATUS EVENT:", studentId, enabled, typeof enabled);
    console.log("CURRENT STUDENT:", currentStudentId, typeof currentStudentId);

    if (String(currentStudentId) !== String(studentId)) {
        console.log("STATUS SKIPPED: другой студент");
        return;
    }

    const status = document.querySelector(".student-status");

    if (!status) {
        console.log("STATUS ELEMENT NOT FOUND");
        return;
    }

    if (enabled === true) {
        status.classList.remove("offline");
        status.classList.add("online");
        status.textContent = "● Онлайн";
        console.log("STATUS SET: ONLINE");
    } else {
        status.classList.remove("online");
        status.classList.add("offline");
        status.textContent = "● Офлайн";
        console.log("STATUS SET: OFFLINE");
    }
}

ws.onmessage = (event) => {
    const data = JSON.parse(event.data);

    if (data.type === "new_message") {

        // Добавляем сообщение в чат
        if (String(currentChatId) === String(data.chatId)) {
            renderMessage("student", data.text);
        }

        let chatItem = document.querySelector(`.chat-item[data-chat-id="${data.chatId}"]`);

        if (chatItem) {
            // Чат уже есть — обновляем последнее сообщение
            chatItem.querySelector(".last-message").textContent = data.text;
        } else {
            // Новый студент — создаем элемент
            chatItem = document.createElement("div");
            chatItem.className = "chat-item";
            chatItem.dataset.chatId = data.chatId;
            chatItem.dataset.studentId = data.studentId;

            chatItem.innerHTML = `
                <div class="name">${data.studentName}</div>
                <div class="phone">${data.phone}</div>
                <div class="last-message">${data.text}</div>
                <button class="delete-chat">🗑</button>
            `;

            chatItem.addEventListener("click", () => {
                openChat(data.chatId, data.studentId, data.studentName);
            });

            chatItem.querySelector(".delete-chat").addEventListener("click", (e) => {
                e.stopPropagation();
                deleteChat(data.chatId);
            });

            chatList.appendChild(chatItem);
        }
    }

    if (data.type === "consultant_mode_changed") {
        updateStudentStatus(
            data.studentId,
            data.enabled
        );
    }
};
async function loadConsultantStatus(studentId) {
    const response = await fetch(
        `http://localhost:8000/consultant-mode?studentId=${studentId}`
    );

    if (!response.ok) {
        return;
    }

    const data = await response.json();

    updateStudentStatus(data.studentId, data.enabled);
}

async function openChat(chatId) {
    currentChatId = chatId;

    const studn = document.getElementById("studentName");

    const activeItem = document.querySelector(
        `.chat-item[data-chat-id="${chatId}"]`
    );

    if (!activeItem) {
        return;
    }

    currentStudentId = activeItem.dataset.studentId;

    document.querySelectorAll(".chat-item").forEach(item => {
        item.classList.remove("active");
    });

    activeItem.classList.add("active");

    const name = activeItem.querySelector(".name");

    if (name) {
        studn.textContent = name.textContent;
    }

    await loadConsultantStatus(currentStudentId);

    const response = await fetch(
        `http://localhost:8000/message?chatId=${chatId}`
    );

    if (!response.ok) {
        return;
    }

    const messages = await response.json();

    const chatBody = document.getElementById("chatBody");

    chatBody.innerHTML = "";

    messages.forEach(message => {
        renderMessage(message.sender, message.text);
    });
}

const sendBtn = document.getElementById("sendBtn");

sendBtn.addEventListener("click", sendMessage);

async function sendMessage() {

    if (!currentChatId) return;

    const input = document.getElementById("messageInput");

    const text = input.value.trim();

    if (!text) return;

    const response = await fetch("http://localhost:8000/send-message", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            chatId: currentChatId,
            text: text
        })
    });

    if (response.ok) {
        renderMessage("employee", text);
        input.value = "";
    }
}

document.addEventListener('DOMContentLoaded', () => {
    initEditMode();
    loadProfile();
    loadChats();
    const chatSearchInput = document.getElementById('chatSearchInput');

if (chatSearchInput) {
    chatSearchInput.addEventListener('input', () => {
        const value = chatSearchInput.value.toLowerCase().trim();

        const filteredChats = allChats.filter(chat => {
            const name = String(chat.student_name || '').toLowerCase();
            const phone = String(chat.phone || '').toLowerCase();

            return name.includes(value) || phone.includes(value);
        });

        renderChats(filteredChats);
    });
}
});